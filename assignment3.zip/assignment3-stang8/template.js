module.exports = {
  confirm: () => ({
    subject: 'Welcome | Airbnb',
    html: `
    <h3>Welcome to Airbnb</h3>
    `,
  })
}
