# assignment3 stang8
 assignment 3  web222
